/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.csit228g3.nabua.nabua_final_project;

/**
 *
 * @author RONNA
 */
public class Nabua_Final_Project {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.csit228g3.nabua.nabua_final_project;

/**
 *
 * @author RONNA
 */
public class MySQLConnection {
    
}
